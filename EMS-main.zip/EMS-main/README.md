# EMS
Employment Management System.
It is a simple employee management system project which stores employee details.
